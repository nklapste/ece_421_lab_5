###### block examples

### example 1
10.times do
  puts "Hello from a block!"
end

### example 2
10.times {puts "Hello from a block!"}

sum = 0

### example 3
[1, 2, 3, 4, 5].each do |num|
  sum += num
end

######..or..######

 [1, 2, 3, 4, 5].each { |num| sum += num }

puts "Sum of the passed numbers: #{sum}"