### example - the yield keyword

def block_example
	puts “inside method”
	yield
	puts “back inside method again”
end
block_example {puts “inside block”}


### example - yeild with parameters

def block_test
	puts “inside method”
	yield 100
	puts “back inside method again”
end
block_test {|arg| puts “the yield has passed #{arg} to this block”}
